<?php
require_once 'koneksi.php';
logout();
?>